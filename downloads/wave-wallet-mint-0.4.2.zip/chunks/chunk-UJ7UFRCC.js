// src/shared/config.js
var VERSION = "0.4.2";
var RPC_URL = "https://eth-rpc-api.thetatoken.org/rpc";
var EXPLORER = "https://explorer.thetatoken.org";
var WAVE_TOKEN = "0x93de35b55ace27cee301184e010de73518950753";
var PRIVATE_TAGS = ["user:private", "user:memory", "user:import"];
var NAME_KEYS = { "wave.bot": "ref", "wave.site": "ref", "wave.avatar": "ref", "wave.mcp": "url" };
var ABI = [
  "function mint(bytes content, string[] tags, uint256 supersedes, bool isPrivate, bytes32 recipientId) returns (uint256 id)",
  "function mintBatch((bytes content, string[] tags, uint256 supersedes, bool isPrivate, bytes32 recipientId)[] items) returns (uint256 firstId)",
  "function transfer(address to, uint256 amount) returns (bool)",
  "function balanceOf(address owner) view returns (uint256)",
  "function setText(bytes32 node, string key, string value)",
  "function text(bytes32 node, string key) view returns (string)",
  "function owner(bytes32 node) view returns (address)",
  "function resolver(bytes32 node) view returns (address)",
  "function isApprovedForAll(address owner, address operator) view returns (bool)",
  "function cards(uint256 id) view returns (address creator, uint40 mintedAt, uint48 mintBlock, bool isPrivate, bytes32 contentHash)",
  "event CardMinted(uint256 indexed id, address indexed creator, bytes32 indexed firstTagHash, bytes32 contentHash, uint256 supersedes, bool isPrivate, bytes32 recipientId, string[] tags, bytes content)"
];
var CAPS = {
  maxTags: 8,
  maxTagBytes: 64,
  batchMax: 50,
  // contract MAX_BATCH
  memoryCardBytes: 4096,
  // Wave Web policy for memory cards (info above this)
  fileCardBytes: 131072,
  // Wave Web policy for files (hard cap)
  txGasMax: 199e5,
  // block is 20M
  gasBuffer: 1.25,
  projectMaxCards: 500,
  projectMaxTfuel: 250,
  projectBalanceBuffer: 1.05,
  projectExpiryMs: 30 * 60 * 1e3,
  requestTimeoutMs: 5 * 60 * 1e3
};
var TYPICAL_CARD_GAS = 425e3;
var PATHS = {
  ethereum: "m/44'/60'/0'/0/0",
  theta: "m/44'/500'/0'/0/0"
};
var CAPABILITIES = {
  version: VERSION,
  decodedMint: true,
  batchMax: CAPS.batchMax,
  projectMint: true,
  privateCards: true,
  privateFormat: "pv1",
  privateTags: PRIVATE_TAGS,
  tokens: ["TFUEL", "WAVE"],
  nameRecords: true,
  nameKeys: Object.keys(NAME_KEYS),
  nameRefSha: true,
  waveSignIn: true,
  memorySessions: true,
  gasBatches: true,
  agentKeys: true
};

export {
  RPC_URL,
  EXPLORER,
  WAVE_TOKEN,
  ABI,
  TYPICAL_CARD_GAS,
  PATHS
};
