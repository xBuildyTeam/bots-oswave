(() => {
  // src/shared/config.js
  var VERSION = "0.4.2";
  var PRIVATE_TAGS = ["user:private", "user:memory", "user:import"];
  var NAME_KEYS = { "wave.bot": "ref", "wave.site": "ref", "wave.avatar": "ref", "wave.mcp": "url" };
  var CAPS = {
    maxTags: 8,
    maxTagBytes: 64,
    batchMax: 50,
    // contract MAX_BATCH
    memoryCardBytes: 4096,
    // Wave Web policy for memory cards (info above this)
    fileCardBytes: 131072,
    // Wave Web policy for files (hard cap)
    txGasMax: 199e5,
    // block is 20M
    gasBuffer: 1.25,
    projectMaxCards: 500,
    projectMaxTfuel: 250,
    projectBalanceBuffer: 1.05,
    projectExpiryMs: 30 * 60 * 1e3,
    requestTimeoutMs: 5 * 60 * 1e3
  };
  var CAPABILITIES = {
    version: VERSION,
    decodedMint: true,
    batchMax: CAPS.batchMax,
    projectMint: true,
    privateCards: true,
    privateFormat: "pv1",
    privateTags: PRIVATE_TAGS,
    tokens: ["TFUEL", "WAVE"],
    nameRecords: true,
    nameKeys: Object.keys(NAME_KEYS),
    nameRefSha: true,
    waveSignIn: true,
    memorySessions: true,
    gasBatches: true,
    agentKeys: true
  };
  var PROVIDER_INFO = {
    name: "Wave Wallet Mint",
    rdns: "io.oswave.wallet"
  };

  // src/shared/icon.js
  var ICON_DATA_URI = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMjggMTI4Ij48ZGVmcz48bGluZWFyR3JhZGllbnQgaWQ9ImEiIHgxPSIwIiB5MT0iMCIgeDI9IjEiIHkyPSIxIj48c3RvcCBvZmZzZXQ9IjAiIHN0b3AtY29sb3I9IiNhNmY1YzQiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiMyZmI4NmEiLz48L2xpbmVhckdyYWRpZW50PjxsaW5lYXJHcmFkaWVudCBpZD0iYiIgeDE9IjAiIHkxPSIwIiB4Mj0iMSIgeTI9IjEiPjxzdG9wIG9mZnNldD0iMCIgc3RvcC1jb2xvcj0iIzdmZTZhNiIvPjxzdG9wIG9mZnNldD0iMSIgc3RvcC1jb2xvcj0iIzFmOWE1NSIvPjwvbGluZWFyR3JhZGllbnQ+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMjgiIGhlaWdodD0iMTI4IiByeD0iMjgiIGZpbGw9IiMxMTFhMTgiLz48ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgyNCAyMikgc2NhbGUoMS4yNSkiPjxwYXRoIGQ9Ik0zMCA1OCBDMTAgNTIgNCAzMCAxNCAxMCBDMzQgMTIgNDQgMzQgMzAgNThaIiBmaWxsPSJ1cmwoI2IpIi8+PHBhdGggZD0iTTMwIDU4IEMyOCA0MCAyMiAyNCAxNCAxMCIgc3Ryb2tlPSIjMGY2YjNhIiBzdHJva2Utd2lkdGg9IjIiIGZpbGw9Im5vbmUiIG9wYWNpdHk9Ii41NSIvPjxwYXRoIGQ9Ik0zMiA1OCBDMzAgMzQgNDIgMTQgNjAgOCBDNjQgMzAgNTQgNTIgMzIgNThaIiBmaWxsPSJ1cmwoI2EpIi8+PHBhdGggZD0iTTMyIDU4IEMzOCA0MCA0OCAyMiA2MCA4IiBzdHJva2U9IiMxMzdhNDIiIHN0cm9rZS13aWR0aD0iMi4yIiBmaWxsPSJub25lIiBvcGFjaXR5PSIuNiIvPjxwYXRoIGQ9Ik0zOCA0NCBMNDggNDIgTTQyIDM0IEw1MyAzMCBNNDYgMjUgTDU2IDIwIE0zNiA1MCBMNDQgNTEiIHN0cm9rZT0iIzEzN2E0MiIgc3Ryb2tlLXdpZHRoPSIxLjYiIG9wYWNpdHk9Ii40NSIvPjwvZz48cmVjdCB4PSIyMCIgeT0iMTA0IiB3aWR0aD0iODgiIGhlaWdodD0iNiIgcng9IjMiIGZpbGw9IiMxOGQ4YmEiLz48L3N2Zz4K";

  // src/inpage/inpage.js
  (() => {
    if (window.__waveWalletMint) return;
    const TO_CONTENT = "wwm:to-content";
    const TO_PAGE = "wwm:to-page";
    const pending = /* @__PURE__ */ new Map();
    const listeners = /* @__PURE__ */ new Map();
    const rid = () => crypto.getRandomValues(new Uint32Array(4)).join("-");
    function emit(event, data) {
      for (const fn of listeners.get(event) || []) {
        try {
          fn(data);
        } catch (e) {
          console.error(e);
        }
      }
    }
    window.addEventListener("message", (ev) => {
      if (ev.source !== window || ev.origin !== location.origin) return;
      const m = ev.data;
      if (!m || m.channel !== TO_PAGE) return;
      if (m.event) return emit(m.event, m.data);
      const p = pending.get(m.id);
      if (!p) return;
      pending.delete(m.id);
      if (m.error) {
        const err = new Error(m.error.message);
        err.code = m.error.code;
        if (m.error.data) err.data = m.error.data;
        p.reject(err);
      } else p.resolve(m.result);
    });
    const provider = {
      isWaveWalletMint: true,
      isMetaMask: false,
      request({ method, params } = {}) {
        if (typeof method !== "string") return Promise.reject(Object.assign(new Error("method is required"), { code: -32600 }));
        const id = rid();
        return new Promise((resolve, reject) => {
          pending.set(id, { resolve, reject });
          window.postMessage({ channel: TO_CONTENT, id, method, params: params ?? [] }, location.origin);
        });
      },
      on(event, fn) {
        if (!listeners.has(event)) listeners.set(event, /* @__PURE__ */ new Set());
        listeners.get(event).add(fn);
        return provider;
      },
      removeListener(event, fn) {
        listeners.get(event)?.delete(fn);
        return provider;
      }
    };
    provider.off = provider.removeListener;
    Object.freeze(provider);
    const info = Object.freeze({ uuid: crypto.randomUUID(), name: PROVIDER_INFO.name, icon: ICON_DATA_URI, rdns: PROVIDER_INFO.rdns });
    const announce = () => window.dispatchEvent(new CustomEvent("eip6963:announceProvider", { detail: Object.freeze({ info, provider }) }));
    window.addEventListener("eip6963:requestProvider", announce);
    announce();
    Object.defineProperty(window, "__waveWalletMint", { value: provider, writable: false, configurable: false });
  })();
})();
