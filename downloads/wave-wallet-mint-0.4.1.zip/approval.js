import {
  $,
  LEAF,
  call,
  h,
  short,
  tfuel,
  unlockForm,
  usd,
  wave
} from "./chunks/chunk-WPMQQOK6.js";

// src/ui/approval.js
var id = new URLSearchParams(location.search).get("id");
var root = $("#app");
setInterval(() => call("ping").catch(() => {
}), 2e4);
var KIND_TITLE = { connect: "Connect", mint: "Mint 1 card to BrainVault v3", mintBatch: "", project: "", sendTfuel: "Send TFUEL", sendWave: "Send WAVE", setText: "Point a name" };
function bar(origin) {
  return h("div", { class: "hd" }, h("div", { class: "brand", style: "font-size:13px" }, LEAF(14), "Wave Wallet ", h("span", { class: "mint" }, "Mint"), h("span", { class: "muted", style: "font-weight:400" }, " \xB7 approval")));
}
function cardText(c) {
  if (c.isPrivate && c.plain == null) return h("div", { class: "card" }, "Encrypted card (private). Recipient " + short("0x" + c.recipientId.slice(-40)));
  if (c.isPrivate) {
    const full2 = c.plain;
    const long2 = full2.length > 600;
    const el2 = h("div", { class: "card" }, long2 ? full2.slice(0, 600) + "\u2026" : full2);
    const head = h("div", { class: "priv" }, c.readableBy ? `Private \xB7 readable by you + ${c.readableBy} \xB7 ` : "Private \xB7 encrypted to you \xB7 ", `${c.plainSize.toLocaleString()} bytes inside, ${c.size.toLocaleString()} on chain`);
    if (!long2) return h("div", {}, head, el2);
    const more2 = h("button", { class: "more", onclick: () => {
      el2.textContent = full2;
      more2.remove();
    } }, "Show full text");
    return h("div", {}, head, el2, more2);
  }
  if (c.binary) return h("div", { class: "card mono" }, `Binary content, ${c.size.toLocaleString()} bytes`);
  const full = c.text;
  const long = full.length > 600;
  const el = h("div", { class: "card" + (/[{};<>]|^\s{2,}/m.test(full) ? " mono" : "") }, long ? full.slice(0, 600) + "\u2026" : full);
  if (!long) return el;
  const more = h("button", { class: "more", onclick: () => {
    el.textContent = full;
    more.remove();
  } }, "Show full text");
  return h("div", {}, el, more);
}
function chips(c) {
  return h("div", { class: "chips" }, c.tags.map((t) => h("span", { class: "chip" }, t)), c.supersedes !== "0" ? h("span", { class: "chip" }, `corrects v3:${c.supersedes}`) : null);
}
function problems(cards) {
  const blocked = cards.filter((c) => c.errors.length || c.warnings.some((w) => w.level === "block"));
  const warned = cards.filter((c) => !blocked.includes(c) && c.warnings.length);
  return { blocked, warned };
}
function problemBoxes(cards) {
  const { blocked, warned } = problems(cards);
  const out = [];
  for (const c of blocked) {
    const why = [...c.errors, ...c.warnings.filter((w) => w.level === "block").map((w) => `looks like it contains ${w.label}`)];
    out.push(h("div", { class: "warn" }, h("b", {}, cards.length > 1 ? `Card ${c.index + 1} can't be minted. ` : "This card can't be minted. "), why.join(". ") + (c.isPrivate ? ". Fix it in Wave Web." : ". Fix it in Wave Web. Public cards are readable by anyone, forever.")));
  }
  for (const c of warned) {
    out.push(h("div", { class: "warn" }, h("b", {}, cards.length > 1 ? `Card ${c.index + 1} ` : "This card "), "looks like it contains " + c.warnings.map((w) => w.label).join(" and ") + (c.isPrivate ? ". It's encrypted, but anyone who ever gets this wallet's key could read it." : ". Public cards are permanent.")));
  }
  return { out, blocked, warned };
}
async function main() {
  const r = await call("getRequest", { id }).catch((e) => ({ error: e.message }));
  if (r.error) {
    root.append(bar(), h("div", { class: "pad err" }, r.error));
    return;
  }
  const req = r.request;
  const st = await call("status");
  if (req.progress) return renderProgress(req);
  if (!st.unlocked) {
    root.innerHTML = "";
    root.append(bar(), site(req.origin), unlockForm(st.address, () => {
      root.innerHTML = "";
      main();
    }));
    return;
  }
  root.innerHTML = "";
  if (req.kind === "connect") return renderConnect(req, st);
  if (req.kind === "signin") return renderSignin(req, st);
  if (req.kind === "memory") return renderMemory(req, st);
  if (req.kind === "agentKey") return renderAgentKey(req, st);
  return renderTx(req, st);
}
function renderSignin(req, st) {
  const si = req.signin;
  const mins = Math.max(1, Math.round((si.expiresAt - Date.now()) / 6e4));
  const f = footer("Sign in", async () => {
    await call("approve", { id });
    window.close();
  });
  root.append(bar(), site(req.origin), h(
    "div",
    { class: "pad grow" },
    h("div", { class: "title" }, `Sign in to Wave on ${si.host}`),
    h("p", { class: "muted", style: "margin-top:8px;line-height:1.5" }, "This is free and sends no transaction. It lets this site manage your bots for this session."),
    h(
      "div",
      { class: "kv" },
      h("div", {}, h("span", {}, "Account"), h("b", {}, short(st.address))),
      h("div", {}, h("span", {}, "Site"), h("b", {}, si.host)),
      h("div", {}, h("span", {}, "Request expires"), h("b", {}, `in ${mins} min`))
    ),
    h("p", { class: "muted small", style: "margin-top:10px" }, "Wave Wallet Mint only signs Wave sign-in messages. It never signs anything that could move funds or reveal keys.")
  ), f.el);
}
function renderMemory(req, st) {
  const m = req.memory;
  const who = m.bot || new URL(req.origin).host;
  const dur = m.minutes % 60 === 0 ? m.minutes === 60 ? "1 hour" : `${m.minutes / 60} hours` : `${m.minutes} minutes`;
  const scope = m.refs === "all" ? "All your private cards" : `${m.refs.length} card${m.refs.length === 1 ? "" : "s"}: ${m.refs.slice(0, 10).join(", ")}${m.refs.length > 10 ? "\u2026" : ""}`;
  const f = footer("Allow", async () => {
    await call("approve", { id });
    window.close();
  });
  root.append(bar(), site(req.origin), h(
    "div",
    { class: "pad grow" },
    h("div", { class: "title" }, `Let ${who} read your private cards for ${dur}?`),
    h(
      "div",
      { class: "kv" },
      h("div", {}, h("span", {}, "Account"), h("b", {}, short(st.address))),
      h("div", {}, h("span", {}, "Cards"), h("b", {}, scope)),
      h("div", {}, h("span", {}, "For"), h("b", {}, dur))
    ),
    h("div", { class: "warn", style: "margin-top:10px" }, "The page will see the decrypted text. Your AI provider may see what the bot reads."),
    h("p", { class: "muted small", style: "margin-top:10px" }, "Only cards minted by this wallet can be opened. Access ends when it expires, when you lock the wallet, or when you end it in Settings \u203A Connected sites.")
  ), f.el);
}
function renderAgentKey(req, st) {
  const label = req.agentKey.label;
  const ack = h("input", { type: "checkbox" });
  const f = footer("Create key", async () => {
    await call("approve", { id, acknowledged: ack.checked });
    window.close();
  }, false);
  ack.onchange = () => {
    f.ok.disabled = !ack.checked;
  };
  root.append(bar(), site(req.origin), h(
    "div",
    { class: "pad grow" },
    h("div", { class: "title" }, `Give ${label} its own memory key?`),
    h("p", { class: "muted", style: "margin-top:8px;line-height:1.5" }, `${label} will be able to read the private cards you encrypt for it, on its own, from any computer it runs on. It can't spend from your wallet or sign for it.`),
    h(
      "div",
      { class: "kv" },
      h("div", {}, h("span", {}, "Wallet"), h("b", {}, short(st.address))),
      h("div", {}, h("span", {}, "Agent"), h("b", {}, label)),
      h("div", {}, h("span", {}, "Sent to"), h("b", {}, "this agent only, encrypted"))
    ),
    h("div", { class: "warn", style: "margin-top:10px" }, "Anyone who gets this agent key can read every card encrypted to it, forever. Revoking it later stops new cards, not old ones. Use one key per agent and computer."),
    h("label", { class: "ck", style: "margin-top:10px" }, ack, "I understand old cards stay readable by it even if I revoke it later"),
    h("p", { class: "muted small", style: "margin-top:8px" }, "Your wallet keeps a copy, and your normal wallet backup restores it.")
  ), f.el);
}
function site(origin) {
  return h("div", { class: "pad", style: "padding-bottom:0" }, h("div", { class: "site" }, "Request from", h("b", {}, origin)));
}
function footer(approveLabel, onApprove, enabled = true) {
  const err = h("div", { class: "err", style: "padding:0 16px" });
  const ok = h("button", { class: "b b1", disabled: !enabled }, approveLabel);
  const no = h("button", { class: "b b2" }, "Reject");
  no.onclick = async () => {
    await call("reject", { id });
    window.close();
  };
  ok.onclick = async () => {
    err.textContent = "";
    ok.disabled = true;
    no.disabled = true;
    ok.textContent = "Signing\u2026";
    try {
      await onApprove();
    } catch (e) {
      err.textContent = e.message;
      ok.disabled = false;
      no.disabled = false;
      ok.textContent = approveLabel;
    }
  };
  return { el: h("div", {}, err, h("div", { class: "btns" }, no, ok)), ok };
}
function renderConnect(req, st) {
  const f = footer("Connect", async () => {
    await call("approve", { id });
    window.close();
  });
  root.append(bar(), site(req.origin), h(
    "div",
    { class: "pad grow" },
    h("div", { class: "title" }, "Connect to this site?"),
    h("p", { class: "muted", style: "margin-top:8px;line-height:1.5" }, "The site will see your address and balances, and can ask you to approve mints and sends. Every transaction still needs your approval."),
    h("div", { class: "kv" }, h("div", {}, h("span", {}, "Account"), h("b", {}, short(st.address))), h("div", {}, h("span", {}, "Network"), h("b", {}, "Theta mainnet")))
  ), f.el);
}
async function renderTx(req, st) {
  const d = req.decoded;
  const cards = d.cards || [];
  const n = cards.length;
  const title = req.kind === "mintBatch" ? `Mint ${n} cards` : req.kind === "project" ? `Mint project \xB7 ${n} cards in ${req.batches.length} batches` : KIND_TITLE[req.kind];
  const costRow = h("b", { class: "big" }, "estimating\u2026");
  const after = h("b", {}, "\u2026");
  const quoteErr = h("div");
  const body = h("div", { class: "pad grow" });
  root.append(bar(), site(req.origin), body);
  body.append(h("div", { class: "title" }, title.startsWith("Mint") ? [h("span", { class: "mint" }, "Mint"), title.slice(4)] : title));
  if (req.kind === "project" && req.name) body.append(h("div", { class: "muted small", style: "margin-top:4px" }, req.name));
  const { out, blocked, warned } = problemBoxes(cards);
  out.forEach((x) => body.append(x));
  if (req.kind === "mint") {
    const c = cards[0];
    body.append(cardText(c), chips(c), h(
      "div",
      { class: "kv" },
      h("div", {}, h("span", {}, "Size"), h("b", {}, `${c.size.toLocaleString()} bytes \xB7 ${c.isPrivate ? "private" : "public"}`)),
      h("div", {}, h("span", {}, "Signer"), h("b", {}, short(st.address))),
      h("div", {}, h("span", {}, "Cost"), costRow),
      h("div", {}, h("span", {}, "Balance after"), after)
    ));
  } else if (n) {
    const total = cards.reduce((s, c) => s + c.size, 0);
    const list = h("div", { class: "list", style: "margin-top:10px" });
    for (const c of cards) {
      const bad = blocked.includes(c);
      const soft = warned.includes(c);
      const first = c.isPrivate ? (c.readableBy ? `Private (you + ${c.readableBy}) \xB7 ` : "Private \xB7 ") + ((c.plain || "Encrypted card").split("\n").find((l) => l.trim()) || "").slice(0, 50) : c.binary ? "Binary content" : (c.text.split("\n").find((l) => l.trim()) || "").slice(0, 60);
      const row = h(
        "div",
        { class: "it" + (bad ? " bad" : soft ? " soft" : "") },
        h("div", {}, h("div", { class: "t" }, `${c.index + 1}. ${first}`), h("div", { class: "s" }, c.tags.join(" \xB7 ") || "no tags")),
        h("div", { class: "s" }, `${(c.size / 1024).toFixed(1)} KB`)
      );
      const det = h("div", { class: "body" }, cardText(c), chips(c));
      row.onclick = () => row.classList.toggle("open");
      list.append(row, det);
    }
    body.append(list, h(
      "div",
      { class: "kv" },
      h("div", {}, h("span", {}, "Total size"), h("b", {}, `${(total / 1024).toFixed(1)} KB`)),
      req.kind === "project" ? h("div", {}, h("span", {}, "Signing"), h("b", {}, `${req.batches.length} transactions, one after another`)) : null,
      h("div", {}, h("span", {}, "Total cost"), costRow),
      h("div", {}, h("span", {}, "Balance after"), after)
    ));
  } else if (req.kind === "setText") {
    const what = { "wave.bot": "bot", "wave.site": "site", "wave.avatar": "mascot", "wave.mcp": "MCP endpoint" }[d.key] || d.key;
    const name = d.name || `name ${short(d.node)}`;
    body.append(...[
      h("div", { class: "card" }, `Point ${name} at ${what} ${d.record}`),
      d.name ? null : h("div", { class: "warn" }, "The site sent a raw name update, so the wallet can't show the name in words. Check the owner below."),
      d.current === d.record ? h("div", { class: "info" }, `${name} already points at ${d.record}. Approving changes nothing but still costs gas.`) : null,
      h(
        "div",
        { class: "kv" },
        h("div", {}, h("span", {}, "Name"), h("b", {}, name)),
        h("div", {}, h("span", {}, "Record"), h("b", {}, d.key)),
        h("div", {}, h("span", {}, "Now"), h("b", {}, d.current || "empty")),
        h("div", {}, h("span", {}, "New"), h("b", { class: "big" }, d.record)),
        h("div", {}, h("span", {}, "Owner"), h("b", {}, d.owner && d.owner.toLowerCase() === st.address.toLowerCase() ? "you" : `${short(d.owner || "")} (you're approved)`)),
        h("div", {}, h("span", {}, "Network fee"), costRow),
        h("div", {}, h("span", {}, "TFUEL after"), after)
      )
    ].filter(Boolean));
  } else {
    body.append(h(
      "div",
      { class: "kv" },
      h("div", {}, h("span", {}, "To"), h("b", {}, d.to)),
      h("div", {}, h("span", {}, "Amount"), h("b", { class: "big" }, req.kind === "sendWave" ? `${wave(d.amount)} WAVE` : `${tfuel(d.amount, 4)} TFUEL`)),
      h("div", {}, h("span", {}, "Network fee"), costRow),
      h("div", {}, h("span", {}, "TFUEL after"), after)
    ));
  }
  body.append(quoteErr);
  let ack = null;
  const nPriv = cards.filter((c) => c.isPrivate).length;
  if (nPriv && !blocked.length) {
    body.append(h(
      "div",
      { class: "info" },
      h("b", {}, nPriv === cards.length ? n > 1 ? `All ${n} cards are private. ` : "This card is private. " : `${nPriv} of ${n} cards are private. `),
      "Wave Wallet Mint encrypted them to this wallet (PV1). The chain shows only the size, date and the tags ",
      cards.find((c) => c.isPrivate).tags.join(", ") || "none",
      ". Only this wallet's key can open them."
    ));
  }
  if ((warned.length || nPriv) && !blocked.length) {
    ack = h("input", { type: "checkbox" });
    body.append(h("label", { class: "ck" }, ack, nPriv ? warned.length ? "I understand the warnings, and I have a backup of this wallet. If its key is lost, private cards can never be opened." : "I have a backup of this wallet. If its key is lost, private cards can never be opened." : "I understand, mint anyway"));
  }
  body.append(h("div", { class: "foot" }, req.kind === "setText" ? "Only the TNS public resolver can receive this. It changes one wave.* record. The address, owner and other records stay as they are, and you can change it again later." : cards.length ? nPriv === cards.length ? "Cards are permanent. Private cards are stored encrypted, forever. Only BrainVault v3 can receive this transaction." : "Cards are permanent. Anyone can read public cards forever. Only BrainVault v3 can receive this transaction." : "Sends on Theta can't be reversed. Check the address."));
  const label = req.kind === "project" ? "Approve project" : n > 1 ? "Approve batch" : "Approve";
  const f = footer(label, async () => {
    if (req.kind === "project") {
      renderProgress({ ...req, progress: { done: 0, total: req.batches.length, state: "running" } });
      poll();
    }
    const res = await call("approve", { id, acknowledged: !!ack?.checked });
    if (req.kind === "project") return renderProgress({ ...req, progress: { ...res.result, state: res.result.complete ? "done" : "stopped", result: res.result } });
    window.close();
  }, false);
  root.append(f.el);
  let quoteOk = false;
  const refresh = () => {
    f.ok.disabled = !(quoteOk && !blocked.length && (!ack || ack.checked));
  };
  ack?.addEventListener("change", refresh);
  const q = await call("quote", { id }).catch((e) => ({ errors: [{ error: e.message }] }));
  if (q.errors?.length) {
    costRow.textContent = "can't estimate";
    q.errors.forEach((e) => quoteErr.append(h("div", { class: "warn" }, h("b", {}, req.kind === "project" ? `Batch ${e.batch + 1}: ` : ""), e.error)));
    return;
  }
  const fee = BigInt(q.fee);
  const value = BigInt(q.value);
  const bal = BigInt(q.tfuel);
  const need = req.kind === "project" ? fee * 105n / 100n : fee + value;
  costRow.textContent = `${tfuel(fee, 4)} TFUEL${q.usd ? " \xB7 " + usd(fee, q.usd) : ""}`;
  after.textContent = bal >= need ? `${tfuel(bal - fee - value)} TFUEL` : "not enough TFUEL";
  if (req.kind === "sendWave" && BigInt(q.wave) < BigInt(d.amount)) {
    quoteErr.append(h("div", { class: "warn" }, "Not enough WAVE for this send."));
    return;
  }
  if (bal < need) {
    quoteErr.append(h("div", { class: "warn" }, `You need ${tfuel(need, 4)} TFUEL${req.kind === "project" ? " (cost plus 5%)" : ""} and have ${tfuel(bal, 4)}.`));
    return;
  }
  if (req.kind === "project" && q.feeTfuel > 250) {
    quoteErr.append(h("div", { class: "warn" }, "A project approval is limited to 250 TFUEL. Split it in Wave Web."));
    return;
  }
  quoteOk = true;
  refresh();
}
var polling = false;
function poll() {
  if (polling) return;
  polling = true;
  const tick = async () => {
    const r = await call("getRequest", { id }).catch(() => null);
    const p = r?.request?.progress;
    if (p) {
      const fill = $("#fill");
      if (fill) fill.style.width = `${p.done / p.total * 100}%`;
      const t = $("#ptext");
      if (t && p.state === "running") t.textContent = `Batch ${Math.min(p.done + 1, p.total)} of ${p.total}\u2026`;
      if (p.state !== "running") return;
    }
    setTimeout(tick, 1500);
  };
  tick();
}
function renderProgress(req) {
  const p = req.progress;
  const r = p.result;
  root.innerHTML = "";
  const body = h(
    "div",
    { class: "pad grow" },
    h("div", { class: "title" }, h("span", { class: "mint" }, "Mint"), " project"),
    h("div", { class: "bar" }, h("div", { id: "fill", style: `width:${p.done / p.total * 100}%` })),
    h("div", { id: "ptext", class: "muted small", style: "margin-top:8px" }, r ? "" : `Batch ${p.done + 1} of ${p.total}\u2026`)
  );
  if (r) {
    body.append(r.complete ? h("div", { class: "info" }, `All ${r.cardsMinted} cards minted in ${r.batchesDone} transactions.`) : h("div", { class: "warn" }, h("b", {}, `Stopped after ${r.batchesDone} of ${r.batchesTotal} batches. `), `${r.cardsMinted} cards are minted and saved. ${r.error} Wave Web can resume from card ${r.cardsMinted + 1}.`));
  } else body.append(h("p", { class: "muted small", style: "margin-top:10px" }, "Keep this window open. Each batch waits for the previous one to confirm."));
  root.append(bar(), site(req.origin), body);
  if (r) root.append(h("div", { class: "btns" }, h("button", { class: "b b1", onclick: async () => {
    await call("closeProject", { id });
    window.close();
  } }, "Done")));
}
main();
