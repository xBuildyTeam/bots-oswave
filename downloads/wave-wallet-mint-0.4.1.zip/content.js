(() => {
  // src/content/content.js
  (() => {
    const TO_CONTENT = "wwm:to-content";
    const TO_PAGE = "wwm:to-page";
    window.addEventListener("message", (ev) => {
      if (ev.source !== window || ev.origin !== location.origin) return;
      const m = ev.data;
      if (!m || m.channel !== TO_CONTENT || typeof m.id !== "string" || typeof m.method !== "string") return;
      chrome.runtime.sendMessage({ type: "rpc", method: m.method, params: m.params }, (res) => {
        const err = chrome.runtime.lastError;
        const out = { channel: TO_PAGE, id: m.id };
        if (err) out.error = { code: 4900, message: "Wave Wallet Mint is restarting. Please try again" };
        else if (res?.error) out.error = res.error;
        else out.result = res?.result ?? null;
        window.postMessage(out, location.origin);
      });
    });
    chrome.runtime.onMessage.addListener((msg, sender) => {
      if (sender.id !== chrome.runtime.id || msg?.type !== "event") return;
      window.postMessage({ channel: TO_PAGE, event: msg.event, data: msg.data }, location.origin);
    });
  })();
})();
