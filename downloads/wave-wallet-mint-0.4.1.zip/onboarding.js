import {
  PATHS,
  RPC_URL
} from "./chunks/chunk-YQLQMOA7.js";
import {
  $,
  HDNodeWallet,
  Mnemonic,
  Wallet,
  brand,
  call,
  formatUnits,
  getBytes,
  h,
  hexlify,
  randomBytes,
  short
} from "./chunks/chunk-WPMQQOK6.js";

// src/shared/vault.js
var KDF_ITERATIONS = 6e5;
var enc = new TextEncoder();
var dec = new TextDecoder();
async function deriveKey(password, salt, iterations) {
  const base = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveKey"]);
  return crypto.subtle.deriveKey(
    { name: "PBKDF2", hash: "SHA-256", salt, iterations },
    base,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}
async function sealSecret(secret, password, iterations = KDF_ITERATIONS) {
  if (!password || password.length < 8) throw new Error("Use a password of at least 8 characters");
  const salt = randomBytes(16);
  const iv = randomBytes(12);
  const key = await deriveKey(password, salt, iterations);
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, enc.encode(JSON.stringify(secret))));
  return { v: 1, kdf: "pbkdf2-sha256", iterations, salt: hexlify(salt), iv: hexlify(iv), ct: hexlify(ct) };
}
async function openSecret(sealed, password) {
  const key = await deriveKey(password, getBytes(sealed.salt), sealed.iterations);
  try {
    const pt = await crypto.subtle.decrypt({ name: "AES-GCM", iv: getBytes(sealed.iv) }, key, getBytes(sealed.ct));
    return JSON.parse(dec.decode(pt));
  } catch {
    throw new Error("Wrong password");
  }
}
function createNew() {
  const w = Wallet.createRandom();
  return { address: w.address, privateKey: w.privateKey, mnemonic: w.mnemonic.phrase, path: PATHS.ethereum, source: "created" };
}
function fromPhrase(phrase) {
  const clean = phrase.trim().toLowerCase().split(/\s+/).join(" ");
  if (!Mnemonic.isValidMnemonic(clean)) throw new Error("That recovery phrase isn't valid. Check the words and their order");
  const words = clean.split(" ").length;
  if (![12, 15, 18, 21, 24].includes(words)) throw new Error("A recovery phrase has 12 or 24 words");
  return Object.entries(PATHS).map(([name, path]) => {
    const w = HDNodeWallet.fromPhrase(clean, void 0, path);
    return { address: w.address, privateKey: w.privateKey, mnemonic: clean, path, source: name === "theta" ? "phrase-theta" : "phrase-ethereum" };
  });
}
function fromPrivateKey(pk) {
  let k = pk.trim();
  if (!k.startsWith("0x")) k = "0x" + k;
  if (!/^0x[0-9a-fA-F]{64}$/.test(k)) throw new Error("A private key is 64 hex characters");
  const w = new Wallet(k);
  return { address: w.address, privateKey: w.privateKey, source: "privateKey" };
}
async function fromKeystore(json, password, onProgress) {
  let parsed;
  try {
    parsed = typeof json === "string" ? JSON.parse(json) : json;
  } catch {
    throw new Error("That file isn't a keystore (not JSON)");
  }
  if (!parsed.crypto && parsed.Crypto) parsed = { ...parsed, crypto: parsed.Crypto };
  if (!parsed.crypto) throw new Error("That file isn't a keystore (no crypto section)");
  try {
    const w = await Wallet.fromEncryptedJson(JSON.stringify(parsed), password, onProgress);
    return { address: w.address, privateKey: w.privateKey, source: "keystore" };
  } catch (e) {
    if (/password/i.test(String(e.message))) throw new Error("Wrong keystore password");
    throw new Error("Couldn't open that keystore: " + e.message);
  }
}
async function toKeystore(privateKey, password, onProgress) {
  return new Wallet(privateKey).encrypt(password, onProgress);
}

// src/shared/rpc.js
var nextId = 1;
async function rpc(method, params = []) {
  const res = await fetch(RPC_URL, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ jsonrpc: "2.0", id: nextId++, method, params })
  });
  if (!res.ok) throw new Error(`Theta RPC ${res.status}`);
  const body = await res.json();
  if (body.error) {
    const e = new Error(body.error.message || "RPC error");
    e.code = body.error.code;
    e.data = body.error.data;
    throw e;
  }
  return body.result;
}

// src/ui/onboarding.js
var root = $("#app");
var panel = (...kids) => {
  root.innerHTML = "";
  root.append(h("div", { class: "panel" }, h("div", { class: "hd" }, brand()), h("div", { class: "pad" }, ...kids)));
};
var back = () => h("button", { class: "link", onclick: home }, "\u2190 Back");
async function home() {
  const st = await call("status");
  if (st.hasWallet) {
    if (location.hash === "#export") {
      history.replaceState(null, "", location.pathname);
      return renderExport();
    }
    return panel(
      h("div", { class: "title" }, "Your wallet is set up"),
      h("p", { class: "muted", style: "margin-top:8px" }, `Address ${st.address}. Open it from the leaf icon in Chrome's toolbar.`),
      h("button", { class: "b b2", style: "width:100%;margin-top:14px", onclick: renderExport }, "Download keystore file"),
      h("button", { class: "link", style: "margin-top:14px", onclick: renderRemove }, "Remove this wallet from Chrome")
    );
  }
  panel(
    h("div", { class: "title" }, "Set up Wave Wallet ", h("span", { class: "mint" }, "Mint")),
    h("p", { class: "muted", style: "margin-top:8px;line-height:1.5" }, "Your key is encrypted with your password and stays on this computer. Wave can't see it and can't recover it."),
    h("button", { class: "opt", onclick: renderKeystore }, h("b", {}, "Open a keystore file"), h("span", {}, "The file and password from Theta Wallet, MetaMask or another wallet")),
    h("button", { class: "opt", onclick: renderPhrase }, h("b", {}, "Use a recovery phrase"), h("span", {}, "12 or 24 words from Theta Wallet, MetaMask or any wallet")),
    h("button", { class: "opt", onclick: renderCreate }, h("b", {}, "Create a new wallet"), h("span", {}, "Makes a fresh 12-word recovery phrase")),
    h("button", { class: "opt", onclick: renderKey }, h("b", {}, "Use a private key"), h("span", {}, "Advanced"))
  );
}
function passwordFields(note) {
  const user = h("input", { type: "text", name: "username", autocomplete: "username", value: "wave-wallet-mint", style: "display:none", readonly: true });
  const p1 = h("input", { class: "i", type: "password", name: "new-password", autocomplete: "new-password", placeholder: "At least 8 characters" });
  const p2 = h("input", { class: "i", type: "password", autocomplete: "new-password", placeholder: "Type it again" });
  return {
    el: h(
      "div",
      {},
      user,
      h("label", { class: "f" }, "Wave Wallet Mint password", p1),
      h("label", { class: "f" }, "Confirm password", p2),
      h("p", { class: "muted small", style: "margin-top:6px" }, note || "You'll use this to unlock the wallet. Save it in Google Password Manager or your password manager.")
    ),
    get() {
      if (p1.value.length < 8) throw new Error("Use a password of at least 8 characters");
      if (p1.value !== p2.value) throw new Error("The passwords don't match");
      return p1.value;
    },
    setUser(a) {
      user.value = a;
    }
  };
}
async function save(acct, password) {
  const secret = { privateKey: acct.privateKey, ...acct.mnemonic ? { mnemonic: acct.mnemonic, path: acct.path } : {} };
  const sealed = await sealSecret(secret, password);
  await call("saveAccount", { address: acct.address, source: acct.source, sealed });
  await call("unlock", { password });
  panel(
    h("div", { class: "title" }, "You're set"),
    h("p", { class: "muted", style: "margin-top:8px;line-height:1.5" }, `Wallet ${acct.address} is ready. Pin the leaf icon in Chrome's toolbar, then open Wave Web and choose Wave Wallet Mint.`),
    h("div", { class: "info" }, "Add TFUEL to this address to mint cards. Wave doesn't send TFUEL."),
    h("button", { class: "b b1", style: "width:100%;margin-top:14px", onclick: () => location.href = "https://web.oswave.io" }, "Open Wave Web")
  );
}
function form(kids, label, action) {
  const err = h("div", { class: "err" });
  const btn = h("button", { class: "b b1", type: "submit", style: "width:100%" }, label);
  const f = h("form", { method: "post", action: "#" }, ...kids, err, btn);
  f.addEventListener("submit", async (e) => {
    e.preventDefault();
    err.textContent = "";
    btn.disabled = true;
    const t = btn.textContent;
    btn.textContent = "Working\u2026";
    try {
      await action((s) => btn.textContent = s);
    } catch (x) {
      err.textContent = x.message;
      btn.disabled = false;
      btn.textContent = t;
    }
  });
  return f;
}
function renderKeystore() {
  let json = null;
  const drop = h("div", { class: "card", style: "text-align:center;cursor:pointer;max-height:none;padding:22px" }, "Drop the keystore file here, or click to choose it");
  const file = h("input", { type: "file", accept: ".json,.txt,application/json", style: "display:none" });
  const load = async (f) => {
    json = await f.text();
    drop.textContent = `Loaded ${f.name}`;
  };
  drop.onclick = () => file.click();
  file.onchange = () => file.files[0] && load(file.files[0]);
  drop.ondragover = (e) => e.preventDefault();
  drop.ondrop = (e) => {
    e.preventDefault();
    e.dataTransfer.files[0] && load(e.dataTransfer.files[0]);
  };
  const kpw = h("input", { class: "i", type: "password", autocomplete: "off", placeholder: "The password for this keystore file" });
  const pw = passwordFields("Your Wave Wallet Mint password can be the same as the keystore password.");
  panel(
    back(),
    h("div", { class: "title" }, "Open a keystore file"),
    form([drop, file, h("label", { class: "f" }, "Keystore password", kpw), pw.el], "Open wallet", async (status) => {
      if (!json) throw new Error("Choose a keystore file first");
      const password = pw.get();
      const acct = await fromKeystore(json, kpw.value, (p) => status(`Decrypting\u2026 ${Math.round(p * 100)}%`));
      await save(acct, password);
    })
  );
}
async function balanceOf(a) {
  try {
    return Number(formatUnits(BigInt(await rpc("eth_getBalance", [a, "latest"])), 18)).toFixed(2);
  } catch {
    return "?";
  }
}
function renderPhrase() {
  const ta = h("textarea", { class: "i", autocomplete: "off", spellcheck: "false", placeholder: "word1 word2 word3 \u2026" });
  const pw = passwordFields();
  panel(
    back(),
    h("div", { class: "title" }, "Use a recovery phrase"),
    h("p", { class: "muted small", style: "margin-top:6px" }, "It never leaves this computer."),
    form([h("label", { class: "f" }, "Recovery phrase", ta), pw.el], "Continue", async () => {
      const password = pw.get();
      const options = fromPhrase(ta.value);
      ta.value = "";
      const bals = await Promise.all(options.map((o) => balanceOf(o.address)));
      panel(
        back(),
        h("div", { class: "title" }, "Which address is yours?"),
        h("p", { class: "muted small", style: "margin-top:6px;line-height:1.5" }, "Theta Wallet and MetaMask turn the same phrase into different addresses. Pick the one with your funds."),
        options.map((o, i) => h(
          "button",
          { class: "opt", onclick: () => save(o, password) },
          h("b", {}, short(o.address) + ` \xB7 ${bals[i]} TFUEL`),
          h("span", {}, o.source === "phrase-theta" ? "Theta Wallet style (m/44'/500')" : "MetaMask style (m/44'/60')")
        ))
      );
    })
  );
}
function renderKey() {
  const k = h("input", { class: "i", type: "password", autocomplete: "off", placeholder: "64 hex characters" });
  const pw = passwordFields();
  panel(
    back(),
    h("div", { class: "title" }, "Use a private key"),
    h("div", { class: "warn" }, "Anyone with this key controls the wallet. Only paste it on your own computer."),
    form([h("label", { class: "f" }, "Private key", k), pw.el], "Open wallet", async () => {
      const password = pw.get();
      await save(fromPrivateKey(k.value), password);
    })
  );
}
function renderCreate() {
  const acct = createNew();
  const words = acct.mnemonic.split(" ");
  const grid = h("div", { class: "phrase" }, words.map((w, i) => h("div", {}, h("i", {}, i + 1), w)));
  panel(
    back(),
    h("div", { class: "title" }, "Write down your recovery phrase"),
    h("div", { class: "warn" }, h("b", {}, "This is the only way to recover the wallet. "), "Write the 12 words on paper, in order. Wave can't recover them."),
    grid,
    h("button", { class: "b b1", style: "width:100%;margin-top:14px", onclick: () => confirmWords(acct, words) }, "I wrote them down")
  );
}
function confirmWords(acct, words) {
  const picks = [...crypto.getRandomValues(new Uint8Array(12))].map((v, i) => [v, i]).sort((a, b) => a[0] - b[0]).slice(0, 3).map((x) => x[1]).sort((a, b) => a - b);
  const inputs = picks.map((i) => h("input", { class: "i", autocomplete: "off", spellcheck: "false", placeholder: `Word ${i + 1}` }));
  const pw = passwordFields();
  panel(
    h("div", { class: "title" }, "Check your phrase"),
    form([...picks.map((i, j) => h("label", { class: "f" }, `Word ${i + 1}`, inputs[j])), pw.el], "Create wallet", async () => {
      picks.forEach((i, j) => {
        if (inputs[j].value.trim().toLowerCase() !== words[i]) throw new Error(`Word ${i + 1} doesn't match`);
      });
      await save(acct, pw.get());
    })
  );
}
function renderExport() {
  const p = h("input", { class: "i", type: "password", autocomplete: "current-password", placeholder: "Wave Wallet Mint password" });
  panel(
    back(),
    h("div", { class: "title" }, "Download keystore file"),
    h("p", { class: "muted small", style: "margin-top:6px;line-height:1.5" }, "A standard keystore file (scrypt) protected by your Wave Wallet Mint password. Theta Wallet and MetaMask can open it."),
    form([h("label", { class: "f" }, "Password", p)], "Download", async (status) => {
      const { sealed, address } = await call("getSealed");
      const secret = await openSecret(sealed, p.value);
      const json = await toKeystore(secret.privateKey, p.value, (x) => status(`Encrypting\u2026 ${Math.round(x * 100)}%`));
      const a = h("a", { href: URL.createObjectURL(new Blob([json], { type: "application/json" })), download: `wave-wallet-mint-${address.slice(2, 8).toLowerCase()}.json` });
      a.click();
      status("Downloaded");
    })
  );
}
function renderRemove() {
  panel(
    back(),
    h("div", { class: "title" }, "Remove this wallet?"),
    h("div", { class: "warn" }, "This deletes the encrypted key from Chrome. Your funds stay on Theta, but you'll need your recovery phrase or keystore file to get back in."),
    h("button", { class: "b b2", style: "width:100%;margin-top:14px", onclick: async () => {
      await call("removeAccount");
      home();
    } }, "Remove wallet")
  );
}
if (location.hash === "#export") renderExport();
else home();
